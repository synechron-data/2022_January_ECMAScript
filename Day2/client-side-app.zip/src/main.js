// Import an entire module, for side effects only, without importing anything from the file.
// This will run the module's global code, but doesn't import any values.

// import './1_functions/1_pure_impure_fn';
// import './1_functions/2_iife';
// import './1_functions/3_fn_overloading';
// import './1_functions/4_fn_overloading_assignment';
// import './1_functions/5_arrow_fn';
// import './1_functions/6_fn_as_arguments';
// import './1_functions/7_using_callbacks';
// import './1_functions/8_closures';
// import './1_functions/9_fn_context';
// import './1_functions/10_fn_currying';
// import './1_functions/11_hof';

// import './2_objects/1_object_creation';
// import './2_objects/2_object_type';
// import './2_objects/3_object_methods';
// import './2_objects/4_custom_type';
// import './2_objects/5_using_prototype';
// import './2_objects/6_es6_class';
// import './2_objects/7_compare';
// import './2_objects/8_es5_properties';
import './2_objects/9_es6_properties';


