'use strict'
// var count = 0;

// function next() {
//     return count += 1;
// }

// setInterval(() => {
//     console.log(next());
// }, 2000);

// setTimeout(() => {
//     count = "abc";
// }, 5000);

// --------------------------------------------------

// function next() {
//     var count = 0;
//     return count += 1;
// }

// setInterval(() => {
//     console.log(next());
// }, 2000);

// setTimeout(() => {
//     count = "abc";
// }, 5000);

// --------------------------------------------------

// function getNext() {
//     var count = 0;

//     return function () {
//         return count += 1;
//     }
// }

// const next = getNext();

// setInterval(() => {
//     console.log(next());
// }, 2000);

// --------------------------------------------------

// const next = (function () {
//     var count = 0;

//     return function () {
//         return count += 1;
//     }
// })();

// setInterval(() => {
//     console.log(next());
// }, 2000);

// --------------------------------------------------

// const counter = (function () {
//     var count = 0;

//     function next() {
//         return count += 1;
//     }

//     function prev() {
//         return count -= 1;
//     }

//     return {
//         next: next,
//         prev: prev
//     };
// })();

// const counter = (function () {
//     var count = 0;

//     function next() {
//         return count += 1;
//     }

//     function prev() {
//         return count -= 1;
//     }

//     // ECMASCRIPT 2015 - Object Literal Shortcut
//     return { next, prev };
// })();

// const counter = (function () {
//     var count = 0;

//     return {
//         next: function () {
//             return count += 1;
//         },
//         prev: function () {
//             return count -= 1;
//         }
//     };
// })();

// console.log(counter.next());
// console.log(counter.next());
// console.log(counter.prev());
// console.log(counter.prev());

// ----------------------------------------------------
// If your scenerio requires multiple instances, prefer to do prototyping (encapsulation),
// Donot use the below code (closure), it is not optimized way of creating multiple instances

function getCounter(by = 1) {
    var count = 0;
    var interval = by;

    return {
        next: function () {
            return count += interval;
        },
        prev: function () {
            return count -= interval;
        }
    };
}

var counter = getCounter();
console.log(counter.next());
console.log(counter.next());
console.log(counter.prev());
console.log(counter.prev());

console.log("\n");
var counter5 = getCounter(5);
console.log(counter5.next());
console.log(counter5.next());
console.log(counter5.prev());
console.log(counter5.prev());
