'use strict'

// // In ES ‘this’ refers to the parent of the function and the object through which the function was called
// function test1() {
//     console.log(this);
// }

// test1();

// const test2 = function () {
//     console.log(this);
// }

// test2();

// var self = this;

// console.log("Context of this file: ", this);
// console.log("Global this: ", globalThis);

// // In ES6, arrow functions use lexical scoping — ‘this’ refers to it’s current surrounding scope and no further.
// const test3 = () => {
//     console.log(this);
//     console.log(self === this);
// }

// test3();

// var p1 = {
//     id: 1,
//     test: function () {
//         console.log(this);
//     }
// };

// p1.test();

// -------------------------------------------------- Switching Context
// var p1 = {
//     id: 1
// }

// function check(x, y) {
//     console.log(x, y);
//     console.log(this);
// }

// const check = function (x, y) {
//     console.log(x, y);
//     console.log(this);
// }

// In ES6, arrow functions use lexical scoping — ‘this’ refers to it’s current surrounding scope and no further.
// const check = (x, y) => {
//     console.log(x, y);
//     console.log(this);
// }

// check(2, 3);
// check.call(p1, 2, 3);
// check.apply(p1, [2, 3]);

// --------------------------------------------------

// var person = {
//     age: 0,
//     growOld: function () {
//         console.log("growOld exceuted, under context:", this);
//         this.age += 1;
//     }
// };

// console.log(person.age);

// person.growOld();
// console.log(person.age);

// person.growOld();
// console.log(person.age);

// person.growOld();
// console.log(person.age);

// ---------------------------------------------- Problem
// In ES ‘this’ refers to the parent of the function and the object through which the function was called (invoked)

// var btn = document.createElement("button");
// btn.className = "btn btn-primary btn-block";
// btn.innerHTML = "Click";

// var btnArea = document.getElementById("btnArea");
// btnArea.appendChild(btn);

// btn.addEventListener("click", person.growOld);

// setInterval(person.growOld, 2000);

// ---------------------------------------------- Solution
// var btn = document.createElement("button");
// btn.className = "btn btn-primary btn-block";
// btn.innerHTML = "Click";

// var btnArea = document.getElementById("btnArea");
// btnArea.appendChild(btn);

// btn.addEventListener("click", person.growOld.bind(person));

// setInterval(person.growOld.bind(person), 2000);

// ---------------------------------------------------------------------------
// In ES6, arrow functions use lexical scoping — ‘this’ refers to it’s current surrounding scope and no further.

// var person = {
//     age: 0,
//     growOld: () => {
//         age += 1;
//     }
// };

// function Person() {
//     this.age = 0;
//     this.growOld = function () {
//         console.log("growOld exceuted, under context:", this);
//         this.age += 1;
//     };
// };

// function Person() {
//     var self = this;
//     self.age = 0;
//     self.growOld = function () {
//         console.log("growOld exceuted, under context:", self);
//         self.age += 1;
//     };
// };

function Person() {
    this.age = 0;
    this.growOld = () => {
        console.log("growOld exceuted, under context:", this);
        this.age += 1;
    };
};

var person = new Person();

setInterval(person.growOld, 2000);
// setInterval(person.growOld.bind(person), 2000);


// --------------------------------------------------------------------------- Function Borrowing

// var p1 = {
//     id: 1,
//     name: "Manish",
//     display: function () {
//         console.log(JSON.stringify(this));
//     }
// };

// var p2 = {
//     id: 2,
//     name: "Abhijeet",
//     display: function () {
//         console.log(JSON.stringify(this));
//     }
// };

// p1.display();
// p2.display();

// var p1 = {
//     id: 1,
//     name: "Manish"
// };

// var p2 = {
//     id: 2,
//     name: "Abhijeet"
// };

// const display = function () {
//     console.log(JSON.stringify(this));
// }

// // display.call(p1);
// // display.call(p2);

// p1.display = display.bind(p1);
// p2.display = display.bind(p2);

// p1.display();
// p2.display();

// console.log(p1);