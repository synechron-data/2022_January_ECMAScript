var employees = ["Akshay", "Basavaraj", "Bhavya", "Bibhu", "Chethan", "Chhavi"];

function filter(dataArr, x) {
    let newArr = [];

    for (const name of dataArr) {
        // if (name[0] === x) {
        //     newArr.push(name);
        // }

        // if (name.charAt(0) === x) {
        //     newArr.push(name);
        // }

        // if (name.startsWith(x)) {
        //     newArr.push(name);
        // }

        var testString = "^" + x;
        if (name.match(testString)) {
            newArr.push(name);
        }
    }

    return newArr;
}

var result1 = filter(employees, 'A');
console.log(result1);                   // ["Akshay"];

var result2 = filter(employees, 'B');
console.log(result2);                   // ["Basavaraj", "Bhavya", "Bibhu"];

var result3 = filter(employees, 'C');
console.log(result3);                   // ["Chethan", "Chhavi"];

console.log(employees);                 // ["Akshay", "Basavaraj", "Bhavya", "Bibhu", "Chethan", "Chhavi"];