// // Dev 1
// function getString() {
//     const strArr = ["NodeJS", "ReactJS", "Angular", "ExtJS", "jQuery"];
//     var str = strArr[Math.floor(Math.random() * strArr.length)];
//     return str;
// }

// // Dev 2

// // var s = getString();
// // console.log(s);

// setInterval(() => {
//     var s = getString();
//     console.log(s);
// }, 2000);

// // Call 1 - 1000
// // Call 2 - 3000
// // Call 3 - 1000

// ---------------------------------------------------------------------------

// Dev 1
function pushString(cb) {
    const strArr = ["NodeJS", "ReactJS", "Angular", "ExtJS", "jQuery"];
    setInterval(() => {
        var str = strArr[Math.floor(Math.random() * strArr.length)];
        cb(str);
    }, 2000);
}

// Dev 2
// function processResult(s) {
//     console.log(s);
// }

// pushString(processResult);

// pushString(function (s) {
//     console.log(s);
// });

pushString((s) => {
    console.log(s);
});

// pushString((s) => {
//     console.log("C1 - ", s);
// });

// pushString((s) => {
//     console.log("C2 - ", s);
// });