// function hello() {
//     console.log("Hello World!");
// }

// hello();

// // Immedialtly Invoked Function Expression (IIFE)

// (function () {
//     console.log("Hello World 1");
// })();

// (function () {
//     console.log("Hello World 2");
// }());

// (() => {
//     console.log("Hello World 3");
// })();

// Error - Expected Token
// (() => {
//     console.log("Hello World 4");
// }());

(function (name) {
    console.log(`Hello ${name}`);
})("Abhijeet");

(function (name) {
    console.log(`Hello ${name}`);
}("Ramakant"));

((name) => {
    console.log(`Hello ${name}`);
})("Manish");