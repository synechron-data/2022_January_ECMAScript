// // let obj1 = null;
// // console.log(obj1);
// // console.log(typeof obj1);

// // console.log("\n");
// // let obj2 = new Object();
// // console.log(obj2);
// // console.log(typeof obj2);

// // // Object Literal
// // console.log("\n");
// // let obj3 = {};
// // console.log(obj3);
// // console.log(typeof obj3);

// // JavaScript Object or Value
// var person = {
//     id: 1,
//     name: "Manish",
//     address: {
//         city: "Pune"
//     },
//     display: function () {
//         console.log(this);
//     }
// };

// // person.display();

// console.log(person);
// console.log(typeof person);
// console.log(person.name);

// // Converts a JavaScript value to a JavaScript Object Notation (JSON) string
// const person_JSON = JSON.stringify(person);

// console.log("\n");
// console.log(person_JSON);
// console.log(typeof person_JSON);
// console.log(person_JSON.name);

// // Converts a JavaScript Object Notation (JSON) string into an object.
// const p1 = JSON.parse(person_JSON);

// console.log("\n");
// console.log(p1);
// console.log(typeof p1);
// console.log(p1.name);

// --------------------------------------------- Using Symbol as key

// var person = {
//     id: 1,
//     name: "Manish",
//     username: "ManishS",
//     password: "ManishS",
//     address: {
//         city: "Pune"
//     }
// };

var pwd = Symbol("password");

var person = {
    id: 1,
    name: "Manish",
    [Symbol("username")]: "ManishS",
    [pwd]: "ManishS",
    address: {
        city: "Pune"
    }
};

console.log(person);
console.log(person[pwd]);
console.log(person[Symbol("username")]);                // Not Accessible

const person_JSON = JSON.stringify(person);
console.log(person_JSON);