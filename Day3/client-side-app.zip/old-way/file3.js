var dev1;

(function (ns) {
    function check() {
        console.log("Check from File Three");
    }

    ns.check = check;
})(dev1 = dev1 || {});