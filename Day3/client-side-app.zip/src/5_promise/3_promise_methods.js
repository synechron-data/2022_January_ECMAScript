function firstMethod() {
    var promise = new Promise((resolve, reject) => {
        setTimeout(function () {
            console.log('first method completed...');
            resolve({ first: 'from first method' });
            // reject("first Error");
        }, 2000);
    });
    return promise;
}

function secondMethod() {
    var promise = new Promise((resolve, reject) => {
        setTimeout(function () {
            console.log('second method completed...');
            resolve({ second: 'from second method' });
        }, 3000);
    });
    return promise;
}

function thirdMethod() {
    var promise = new Promise((resolve, reject) => {
        setTimeout(function () {
            console.log('third method completed...');
            resolve({ third: 'from third method' });
        }, 1000);
    });
    return promise;
}

Promise.all([firstMethod(), secondMethod(), thirdMethod()]).then(data => {
    console.log("Final Result: ", data);
}).catch(err => {
    console.error(err);
});

// Promise.race([firstMethod(), secondMethod(), thirdMethod()]).then(data => {
//     console.log("Final Result: ", data);
// }).catch(err => {
//     console.error(err);
// });