// function* idGenerator() {
//     yield 1;
//     yield 2;
//     yield 3;
//     console.log("Last Line of Generator Function");
// }

// let seq = idGenerator();
// console.log(seq.next());
// console.log(seq.next());
// console.log(seq.next());
// console.log(seq.next());

// ------------------------------------------

// function* idGenerator() {
//     console.log("First yield");
//     yield 1;
//     console.log("Second yield");
//     yield 2;
//     console.log("Third yield");
//     yield 3;
//     console.log("Last Line of Generator Function");
// }

// let seq = idGenerator();

// console.warn("Starting Execution");
// console.log(seq.next());
// console.warn("Pause...");
// console.log(seq.next());
// console.warn("Pause...");
// console.log(seq.next());
// console.warn("Pause...");
// console.log(seq.next());

// --------------------------------------------

// class Queue {
//     constructor() {
//         this._dataArray = [];
//     }

//     push(data) {
//         this._dataArray.push(data);
//     }

//     pop() {
//         return this._dataArray.shift();
//     }

//     *[Symbol.iterator]() {
//         yield* this._dataArray;
//     }

//     // *[Symbol.iterator]() {
//     //     for (let i = 0; i < this._dataArray.length; i++) {
//     //         yield this._dataArray[i];
//     //     }
//     // }
// }

// let ordersQueue = new Queue();
// ordersQueue.push("Order Id: 1");
// ordersQueue.push("Order Id: 2");
// ordersQueue.push("Order Id: 3");

// for (const order of ordersQueue) {
//     console.log(order);
// }

// --------------------------------------------

class Fibonacci {
    constructor(noOfItems) {
        this.noOfItems = noOfItems;
    }

    *[Symbol.iterator]() {
        let a = 0, b = 1, i = 0;

        while (i < this.noOfItems) {
            i++;
            let current = a;
            a = b;
            b = current + a;
            yield current;
        }
    }
}

let fibObject = new Fibonacci(10);

let series = [...fibObject];
console.log(series);