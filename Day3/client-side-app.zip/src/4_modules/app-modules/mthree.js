export function test(x) {
    console.warn("From mthree.js file");
    return `Tested: ${x}`;
}