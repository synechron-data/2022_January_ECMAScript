// var person = { id: 1, name: "Manish" };

// // ES 6
// for (const key of Object.keys(person)) {
//     console.log(key, person[key]);
// }

// // ES 8
// // Object.values(), Object.entries()

// for (const value of Object.values(person)) {
//     console.log(value);
// }

// for (const [key, value] of Object.entries(person)) {
//     console.log(`${key} - ${value}`);
// }

// ---------------------------------------------------- getOwnPropertyDescriptor()

var person = {};

Object.defineProperty(person, "firstname", {
    value: "NA",
    writable: true,
    enumerable: true
});

var p_description = Object.getOwnPropertyDescriptor(person, 'firstname');
console.log(p_description);