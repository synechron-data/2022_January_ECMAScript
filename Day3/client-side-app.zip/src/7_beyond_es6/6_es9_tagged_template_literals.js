var fname = "Manish";
var lname = "Sharma";

console.log(`Hello ${fname}; How are you?`);

// function tagFunc(strings, exp) {
//     console.log(strings);
//     console.log(exp);

//     return exp + "\n" + strings[0] + strings[1];
// }

// console.log(tagFunc`Hello ${fname}; How are you?`);
// console.log(String.raw`Hello ${fname}; How are you?`);


function tagFunc(strings, ...exp) {
    console.log(strings);
    console.log(exp);

    return exp + "\n" + strings[0] + strings[1];
}

console.log(tagFunc`Hello ${fname} ${lname}; How are you?`);
