// We cannot specify the type
// We can provide any value to the variable
// We can use any operator with any operand type

// var result = 10 * "abc";
// console.log(result);

// T && T = T
// T && F = F
// F && T = F

// console.log(true && "abc");          // "abc"
// console.log(false && "abc");         // false

// console.log(true ? "abc" : "xyz");
// console.log(false ? "abc" : "xyz");

// console.log(true && "abc" || "xyz");
// console.log(false && "abc" || "xyz");

// function isSelected() {
//     return true;
// }

// If isSelected(), returns true, I want to apply CSS class as text-info else text-danger

{/* <h2 class={{isSelected() && "text-info" || "text-danger"}}></h2>  
<h2 className={isSelected() && "text-info" || "text-danger"}></h2>   */}

// var obj = null;
// var obj = undefined;
// var obj = { id: 1 };

// // if ((obj == null) || (obj == undefined)) {
// //     console.error("object is null or undefined");
// // } else {
// //     console.log("object is:", obj);
// // }

// if (!obj) {
//     console.error("object is null or undefined");
// } else {
//     console.log("object is:", obj);
// }

// ------------------------------------------------------- Comparision

// let a = 10;
// let b = "10";

// console.log(typeof a);
// console.log(typeof b);

// console.log(a == b);        // Abstract Equality
// console.log(a === b);        // Strict Equality

let a = { id: 0 };
let b = { id: 0 };
let c = b;

console.log(a == b);
console.log(a === b);

console.log(b == c);
console.log(b === c);