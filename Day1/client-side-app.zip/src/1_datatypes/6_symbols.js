// const color = "red";

// // Create a function, which should give true, only if, color constant is passed to it
// function isRedColor(str) {
//     console.log(str === color);
// }

// isRedColor(color);
// isRedColor("red");

// var clr = "red";
// isRedColor(clr);

// -------------------------------------------- Object (Mutable)

// const color = { code: "red" };

// // Create a function, which should give true, only if, color constant is passed to it
// function isRedColor(str) {
//     console.log(str === color);
// }

// isRedColor(color);
// isRedColor({ code: "red" });

// var clr = { code: "red" };
// isRedColor(clr);

// -------------------------------------------- Symbol (Unique Immutable)

const color = Symbol("red");

// Create a function, which should give true, only if, color constant is passed to it
function isRedColor(str) {
    console.log(str === color);
}

isRedColor(color);
isRedColor(Symbol("red"));

var clr = Symbol("red");
isRedColor(clr);

var clrCopy = color;
isRedColor(clrCopy);